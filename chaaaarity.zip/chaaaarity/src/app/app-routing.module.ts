import { NgModule } from '@angular/core';
import {  RouterModule, Routes } from '@angular/router';
import { CharityComponent} from './charity/charity.component'
import { ContactComponent } from './contact/contact.component';
import { WorksComponent } from './works/works.component';
import { VolunteerComponent } from './volunteer/volunteer.component';
import { AboutComponent } from './about/about.component';
import { GalleryComponent } from './gallery/gallery.component';

const routes: Routes = [
  { path:'', component:CharityComponent },
  { path:'home', component:CharityComponent},
  { path:'mission', component:AboutComponent},
  { path:'works', component:WorksComponent },
  { path:'contact', component:ContactComponent},
  { path:'gallery', component:GalleryComponent},
  { path:'volunteer', component:VolunteerComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
