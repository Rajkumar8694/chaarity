import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CharityComponent } from './charity/charity.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { GalleryComponent } from './gallery/gallery.component';
import { VolunteerComponent } from './volunteer/volunteer.component';
import { WorksComponent } from './works/works.component';
import { CharityHeaderComponent } from './charity-header/charity-header.component';
import { CharityFooterComponent } from './charity-footer/charity-footer.component';

@NgModule({
  declarations: [
    AppComponent,
    CharityComponent,
    AboutComponent,
    ContactComponent,
    GalleryComponent,
    VolunteerComponent,
    WorksComponent,
    CharityHeaderComponent,
    CharityFooterComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
