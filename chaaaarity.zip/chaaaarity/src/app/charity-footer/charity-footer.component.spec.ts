import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CharityFooterComponent } from './charity-footer.component';

describe('CharityFooterComponent', () => {
  let component: CharityFooterComponent;
  let fixture: ComponentFixture<CharityFooterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CharityFooterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CharityFooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
