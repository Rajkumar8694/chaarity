import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-charity-footer',
  templateUrl: './charity-footer.component.html',
  styleUrls: ['./charity-footer.component.css']
})
export class CharityFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
