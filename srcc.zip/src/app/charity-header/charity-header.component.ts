import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-charity-header',
  templateUrl: './charity-header.component.html',
  styleUrls: ['./charity-header.component.css']
})
export class CharityHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
